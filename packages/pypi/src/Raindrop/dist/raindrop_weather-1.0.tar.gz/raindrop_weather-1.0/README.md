# Raindrop
Raindrop is a slick and intuitive, free and open source weather app for the linux terminal!

full info on github:
https://github.com/metalfoxdev/Raindrop
